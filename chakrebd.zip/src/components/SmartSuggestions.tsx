import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight, Zap, Target, Brain, Star } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from './LanguageContext';
import { ThreeDCard } from './ThreeDCard';

import { Link } from 'react-router-dom';

const SmartSuggestions = () => {
  const { t } = useLanguage();

  const suggestions = [
    {
      id: '1',
      title: 'Top Questions for BCS 2026',
      desc: 'Based on last 10 years trend analysis.',
      tag: 'AI Recommended',
      difficulty: 'Hard',
      icon: Target,
      color: 'text-secondary',
      bg: 'bg-secondary/10',
      size: 'col-span-1 md:col-span-2'
    },
    {
      id: '2',
      title: 'GK Topics',
      desc: 'International affairs & history.',
      tag: 'Trending',
      difficulty: 'Medium',
      icon: Zap,
      color: 'text-yellow-500',
      bg: 'bg-yellow-500/10',
      size: 'col-span-1'
    },
    {
      id: '3',
      title: 'Common Bank Math Patterns',
      desc: 'Focus on Profit/Loss and Interest.',
      tag: 'Must Read',
      difficulty: 'Medium',
      icon: Brain,
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
      size: 'col-span-1'
    },
    {
      id: '4',
      title: 'Daily Quiz',
      desc: 'Test your knowledge daily.',
      tag: 'New',
      difficulty: 'Easy',
      icon: Star,
      color: 'text-green-500',
      bg: 'bg-green-500/10',
      size: 'col-span-1 md:col-span-2'
    }
  ];

  return (
    <section id="suggestions" className="py-24 bg-muted/20 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between mb-16 gap-8">
          <div className="text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold mb-4 uppercase tracking-widest border border-primary/20">
              <Sparkles className="w-4 h-4" />
              <span>Smart Analysis</span>
            </div>
            <h2 className="text-4xl font-bold mb-4">Smart Suggestions</h2>
            <p className="text-muted-foreground max-w-md">Personalized study recommendations powered by our proprietary AI analysis.</p>
          </div>
          <div className="flex items-center gap-2 bg-background/50 backdrop-blur-sm p-1.5 rounded-2xl border border-border shadow-inner">
            <div className="px-6 py-2.5 rounded-xl bg-primary text-white text-sm font-bold shadow-lg shadow-primary/20">All Topics</div>
            <div className="px-6 py-2.5 rounded-xl hover:bg-muted text-sm font-semibold transition-all cursor-pointer">BCS</div>
            <div className="px-6 py-2.5 rounded-xl hover:bg-muted text-sm font-semibold transition-all cursor-pointer">Bank</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {suggestions.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={s.size}
            >
              <ThreeDCard className="h-full">
                <Link to={`/suggestions/${s.id}`} className="h-full block">
                  <Card className="h-full border-border/50 hover:border-primary/50 transition-all duration-500 cursor-pointer group bg-card/50 backdrop-blur-sm rounded-[2.5rem] overflow-hidden">
                    <CardHeader className="pb-4">
                      <div className={`w-14 h-14 rounded-2xl ${s.bg} flex items-center justify-center mb-6 group-hover:rotate-12 transition-transform duration-500`}>
                        <s.icon className={`w-7 h-7 ${s.color}`} />
                      </div>
                      <div className="flex items-center gap-3 mb-4">
                        <Badge variant="outline" className="text-[10px] font-black border-primary/20 text-primary uppercase tracking-tighter">
                          {s.tag}
                        </Badge>
                        <Badge variant="secondary" className="text-[10px] font-black uppercase tracking-tighter">
                          {s.difficulty}
                        </Badge>
                      </div>
                      <CardTitle className="text-2xl group-hover:text-primary transition-colors font-bold tracking-tight">{s.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-8 leading-relaxed">{s.desc}</p>
                      <div className="flex items-center text-sm font-black text-primary group-hover:translate-x-2 transition-transform uppercase tracking-widest">
                        Explore Topic
                        <ArrowRight className="ml-2 w-5 h-5" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </ThreeDCard>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Decorative background elements */}
      <div className="absolute top-1/2 left-0 w-64 h-64 bg-primary/5 rounded-full blur-[100px] -translate-x-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary/5 rounded-full blur-[120px] translate-x-1/4 translate-y-1/4" />
    </section>
  );
};

export default SmartSuggestions;
