import React from 'react';
import { motion } from 'motion/react';
import { 
  Briefcase, Calendar, Lightbulb, Database, 
  FileText, ArrowUpRight, Clock, MapPin, Sparkles 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from './LanguageContext';
import { ThreeDCard } from './ThreeDCard';

import { Link } from 'react-router-dom';

const FeaturedGrid = () => {
  const { t } = useLanguage();

  const features = [
    {
      id: 'jobs',
      title: t('featured.jobs'),
      icon: Briefcase,
      color: 'bg-blue-500',
      href: '/jobs',
      items: [
        { title: '46th BCS Circular', meta: 'Public Service Commission', deadline: '30 Apr 2026' },
        { title: 'Senior Officer', meta: 'Sonali Bank PLC', deadline: '15 May 2026' },
        { title: 'Assistant Teacher', meta: 'Primary Education', deadline: '22 May 2026' },
      ]
    },
    {
      id: 'exams',
      title: t('featured.exams'),
      icon: Calendar,
      color: 'bg-orange-500',
      href: '/prep',
      items: [
        { title: '45th BCS Written', meta: 'Exam Date', date: '12 June 2026' },
        { title: 'Railway Guard', meta: 'Physical Test', date: '05 May 2026' },
        { title: 'BKB Officer', meta: 'Preliminary', date: '20 May 2026' },
      ]
    },
    {
      id: 'suggestions',
      title: t('featured.suggestions'),
      icon: Lightbulb,
      color: 'bg-yellow-500',
      href: '/suggestions',
      items: [
        { title: 'BCS English Literature', meta: 'Top 100 Questions', type: 'PDF' },
        { title: 'Bank Math Shortcuts', meta: 'Profit & Loss', type: 'Video' },
        { title: 'Current Affairs', meta: 'April 2026 Special', type: 'Article' },
      ]
    },
    {
      id: 'qbank',
      title: t('featured.qbank'),
      icon: Database,
      color: 'bg-purple-500',
      href: '/qbank',
      items: [
        { title: 'BCS Preliminary 44th', meta: 'Full Solution', year: '2023' },
        { title: 'Combined Bank 2025', meta: 'Officer Cash', year: '2025' },
        { title: 'Primary Teacher 2024', meta: 'Phase 1 & 2', year: '2024' },
      ]
    }
  ];

  return (
    <section id="jobs" className="py-24 bg-muted/30 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold mb-4 uppercase tracking-widest">
            <Sparkles className="w-4 h-4" />
            <span>Live Updates</span>
          </div>
          <h2 className="text-4xl font-bold mb-4">Explore Our Features</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">Everything you need to succeed in your government job journey, all in one place.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, idx) => (
            <motion.div
              key={feature.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
            >
              <ThreeDCard>
                <Link to={feature.href}>
                  <Card className="h-full hover:shadow-[0_20px_50px_rgba(0,0,0,0.1)] transition-all duration-500 border-border/50 group cursor-pointer overflow-hidden bg-card/80 backdrop-blur-sm rounded-[2rem]">
                    <CardHeader className="pb-6">
                      <div className={`w-14 h-14 rounded-2xl ${feature.color}/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500`}>
                        <feature.icon className={`w-7 h-7 text-${feature.color.split('-')[1]}-500`} />
                      </div>
                      <CardTitle className="text-2xl flex items-center justify-between font-bold">
                        {feature.title}
                        <ArrowUpRight className="w-5 h-5 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {feature.items.map((item, i) => (
                        <div key={i} className="group/item">
                          <p className="text-sm font-bold group-hover/item:text-primary transition-colors line-clamp-1">
                            {item.title}
                          </p>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-xs text-muted-foreground font-medium">{item.meta}</span>
                            {item.deadline && (
                              <Badge variant="outline" className="text-[10px] h-5 px-2 border-secondary/20 text-secondary bg-secondary/5 font-bold">
                                <Clock className="w-3 h-3 mr-1" />
                                {item.deadline}
                              </Badge>
                            )}
                            {item.date && (
                              <Badge variant="outline" className="text-[10px] h-5 px-2 border-primary/20 text-primary bg-primary/5 font-bold">
                                <Calendar className="w-3 h-3 mr-1" />
                                {item.date}
                              </Badge>
                            )}
                          </div>
                          {i < feature.items.length - 1 && <div className="h-px bg-border/30 mt-6" />}
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </Link>
              </ThreeDCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedGrid;
