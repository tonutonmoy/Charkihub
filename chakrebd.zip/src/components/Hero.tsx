import React from 'react';
import { motion } from 'motion/react';
import { Button } from '@/components/ui/button';
import { Search, ArrowRight, CheckCircle2, Star, Sparkles } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { ThreeDCard } from './ThreeDCard';

import { Link } from 'react-router-dom';

const Hero = () => {
  const { t } = useLanguage();

  return (
    <section className="relative pt-32 pb-20 overflow-hidden perspective-1000">
      {/* Background Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 blur-[120px] rounded-full animate-pulse-slow" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-secondary/10 blur-[120px] rounded-full animate-pulse-slow" />
        
        {/* Floating 3D-like shapes */}
        <motion.div 
          animate={{ 
            y: [0, -20, 0],
            rotate: [0, 10, 0]
          }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 right-1/4 w-24 h-24 bg-primary/20 rounded-2xl blur-xl"
        />
        <motion.div 
          animate={{ 
            y: [0, 20, 0],
            rotate: [0, -10, 0]
          }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 left-1/4 w-32 h-32 bg-secondary/20 rounded-full blur-xl"
        />
      </div>

      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Content */}
          <div className="flex-1 text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold mb-8 uppercase tracking-widest border border-primary/20 shadow-sm">
                <Sparkles className="w-4 h-4 fill-primary animate-pulse" />
                <span>Premium Job Prep Platform</span>
              </div>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05] mb-8 tracking-tighter">
                {t('hero.title').split(' ').map((word, i) => (
                  <span key={i} className={i === 2 || i === 3 ? "text-primary" : ""}>
                    {word}{' '}
                  </span>
                ))}
              </h1>
              <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                {t('hero.subtitle')}
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-6 mb-16">
                <Link to="/jobs">
                  <Button size="lg" className="h-16 px-10 text-xl font-bold shadow-2xl shadow-primary/30 group relative overflow-hidden rounded-2xl">
                    <span className="relative z-10 flex items-center gap-2">
                      {t('hero.browse')}
                      <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
                    </span>
                    <div className="absolute inset-0 bg-gradient-to-r from-primary to-primary/80 group-hover:scale-105 transition-transform" />
                  </Button>
                </Link>
                <Link to="/prep">
                  <Button size="lg" variant="outline" className="h-16 px-10 text-xl font-bold rounded-2xl border-2 hover:bg-primary/5 transition-all">
                    {t('hero.start')}
                  </Button>
                </Link>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-8">
                {[
                  { label: "Verified Circulars", icon: CheckCircle2 },
                  { label: "Expert Suggestions", icon: CheckCircle2 },
                  { label: "AI CV Builder", icon: CheckCircle2 }
                ].map((item, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 + i * 0.1 }}
                    className="flex items-center gap-3 bg-card/50 backdrop-blur-sm px-4 py-2 rounded-xl border border-border/50"
                  >
                    <item.icon className="w-5 h-5 text-primary" />
                    <span className="text-sm font-semibold">{item.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* 3D Illustration */}
          <div className="flex-1 relative">
            <ThreeDCard className="relative z-10">
              <div className="relative rounded-[2.5rem] overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] border-4 border-white/10 bg-card group">
                <img 
                  src="https://picsum.photos/seed/chakri/1000/800" 
                  alt="Student success" 
                  className="w-full h-auto object-cover scale-105 group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                
                {/* Floating 3D Elements inside the card */}
                <motion.div
                  style={{ transform: "translateZ(80px)" }}
                  className="absolute top-10 left-10 p-6 bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
                      <CheckCircle2 className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <p className="text-xs font-black text-white/60 uppercase tracking-widest">Success Rate</p>
                      <p className="text-2xl font-black text-white">92% Positive</p>
                    </div>
                  </div>
                </motion.div>

                <motion.div
                  style={{ transform: "translateZ(100px)" }}
                  className="absolute bottom-10 right-10 p-6 bg-primary/90 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center shadow-lg">
                      <Star className="w-8 h-8 text-primary fill-primary" />
                    </div>
                    <div>
                      <p className="text-xs font-black text-white/60 uppercase tracking-widest">Active Users</p>
                      <p className="text-2xl font-black text-white">50K+ Aspirants</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </ThreeDCard>
            
            {/* Decorative background glow */}
            <div className="absolute -inset-10 bg-primary/20 rounded-full blur-[100px] -z-10 animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
