import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'bn' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  bn: {
    'nav.home': 'হোম',
    'nav.jobs': 'সরকারি চাকরি',
    'nav.prep': 'পরীক্ষা প্রস্তুতি',
    'nav.suggestions': 'পরামর্শ',
    'nav.qbank': 'প্রশ্ন ব্যাংক',
    'nav.cv': 'সিভি বিল্ডার',
    'nav.blog': 'ব্লগ',
    'nav.login': 'লগইন',
    'nav.signup': 'সাইনআপ',
    'hero.title': 'বাংলাদেশে আপনার স্বপ্নের সরকারি চাকরি পান',
    'hero.subtitle': 'লেটেস্ট জব সার্কুলার, পরীক্ষার প্রস্তুতি, সাজেশন এবং সিভি বিল্ডার - সব এক প্ল্যাটফর্মে',
    'hero.browse': 'চাকরি খুঁজুন',
    'hero.start': 'প্রস্তুতি শুরু করুন',
    'featured.jobs': 'লেটেস্ট সরকারি চাকরি',
    'featured.exams': 'আসন্ন পরীক্ষা',
    'featured.suggestions': 'পরীক্ষার সাজেশন',
    'featured.qbank': 'প্রশ্ন ব্যাংক',
    'featured.results': 'ফলাফল ও নোটিশ',
    'prep.title': 'পরীক্ষা প্রস্তুতি বিভাগ',
    'prep.bcs': 'বিসিএস',
    'prep.bank': 'ব্যাংক জবস',
    'prep.primary': 'প্রাইমারি',
    'prep.railway': 'রেলওয়ে',
    'prep.others': 'অন্যান্য',
    'cv.title': 'মিনিটেই প্রফেশনাল সরকারি চাকরির সিভি তৈরি করুন',
    'cv.cta': 'সিভি তৈরি করুন',
    'stats.jobs': 'মোট পোস্ট করা চাকরি',
    'stats.users': 'সক্রিয় ব্যবহারকারী',
    'stats.exams': 'কভার করা পরীক্ষা',
    'newsletter.title': 'তাত্ক্ষণিকভাবে চাকরির আপডেট পান',
    'newsletter.button': 'সাবস্ক্রাইব',
    'footer.about': 'আমাদের সম্পর্কে',
    'footer.contact': 'যোগাযোগ',
    'footer.privacy': 'গোপনীয়তা নীতি',
  },
  en: {
    'nav.home': 'Home',
    'nav.jobs': 'Govt Jobs',
    'nav.prep': 'Exam Preparation',
    'nav.suggestions': 'Suggestions',
    'nav.qbank': 'Question Bank',
    'nav.cv': 'CV Builder',
    'nav.blog': 'Blog',
    'nav.login': 'Login',
    'nav.signup': 'Signup',
    'hero.title': 'Get Your Dream Government Job in Bangladesh',
    'hero.subtitle': 'Latest job circulars, exam preparation, suggestions, and CV builder in one platform',
    'hero.browse': 'Browse Jobs',
    'hero.start': 'Start Preparation',
    'featured.jobs': 'Latest Govt Jobs',
    'featured.exams': 'Upcoming Exams',
    'featured.suggestions': 'Exam Suggestions',
    'featured.qbank': 'Question Bank',
    'featured.results': 'Result & Notice Board',
    'prep.title': 'Exam Preparation Section',
    'prep.bcs': 'BCS',
    'prep.bank': 'Bank Jobs',
    'prep.primary': 'Primary',
    'prep.railway': 'Railway',
    'prep.others': 'Others',
    'cv.title': 'Build Professional Govt Job CV in Minutes',
    'cv.cta': 'Create CV',
    'stats.jobs': 'Total Jobs Posted',
    'stats.users': 'Active Users',
    'stats.exams': 'Exams Covered',
    'newsletter.title': 'Get job updates instantly',
    'newsletter.button': 'Subscribe',
    'footer.about': 'About Us',
    'footer.contact': 'Contact',
    'footer.privacy': 'Privacy Policy',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('bn');

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      <div className={language === 'bn' ? 'font-bangla' : 'font-sans'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};
