import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Lightbulb, FileText, Download, Share2, ArrowRight, Sparkles } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ThreeDCard } from '../components/ThreeDCard';

import { Link } from 'react-router-dom';

const MOCK_SUGGESTIONS = [
  { id: '1', title: 'BCS English Literature Suggestions', category: 'BCS', type: 'PDF', date: '12 April 2026', author: 'Dr. Rahim' },
  { id: '2', title: 'Bank Math Shortcut Sheet', category: 'Bank', type: 'PDF', date: '10 April 2026', author: 'Engr. Karim' },
  { id: '3', title: 'Current Affairs Special - April', category: 'General', type: 'Article', date: '08 April 2026', author: 'Editorial Team' },
  { id: '4', title: 'Primary Teacher Final Suggestions', category: 'Primary', type: 'PDF', date: '05 April 2026', author: 'Prof. Selina' },
  { id: '5', title: 'Bangladesh Affairs Top 100 GK', category: 'General', type: 'PDF', date: '02 April 2026', author: 'Team ChakriHub' },
  { id: '6', title: 'Railway Exam Pattern Analysis', category: 'Railway', type: 'Video', date: '01 April 2026', author: 'Expert Panel' },
];

const CATEGORIES = ['All', 'BCS', 'Bank', 'Primary', 'Railway', 'General'];

const Suggestions = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredSuggestions = MOCK_SUGGESTIONS.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold mb-4 uppercase tracking-widest border border-primary/20">
            <Sparkles className="w-4 h-4" />
            <span>Expert Analysis</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">পরামর্শ (Suggestions)</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Get the most effective study suggestions and materials curated by experts for your targeted exams.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 bg-card p-6 rounded-[2rem] shadow-xl shadow-primary/5 border border-border/50">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              placeholder="Search suggestions..." 
              className="pl-12 h-14 rounded-xl border-border/50 focus-visible:ring-primary/30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {CATEGORIES.map(cat => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? 'default' : 'outline'}
                className="rounded-xl h-14 px-6 font-bold whitespace-nowrap"
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Suggestions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredSuggestions.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
            >
              <ThreeDCard>
                <Link to={`/suggestions/${item.id}`}>
                  <Card className="h-full hover:shadow-2xl transition-all duration-500 border-border/50 group bg-card/80 backdrop-blur-sm rounded-[2rem] overflow-hidden">
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start mb-6">
                      <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center group-hover:rotate-12 transition-transform duration-500">
                        <Lightbulb className="w-7 h-7 text-primary" />
                      </div>
                      <Badge variant="outline" className="rounded-lg px-3 py-1 font-black text-[10px] uppercase tracking-widest border-primary/20 text-primary">
                        {item.type}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl font-black group-hover:text-primary transition-colors leading-tight">
                      {item.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex flex-col gap-2">
                      <p className="text-sm font-bold text-muted-foreground">Category: {item.category}</p>
                      <p className="text-xs text-muted-foreground font-medium">By {item.author} • {item.date}</p>
                    </div>
                    <div className="pt-4 flex items-center justify-between border-t border-border/50">
                      <span className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-1">
                        Read More <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </span>
                      <div className="flex gap-2">
                        <Button size="icon" variant="ghost" className="rounded-full w-10 h-10">
                          <Share2 className="w-5 h-5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="rounded-full w-10 h-10 hover:bg-primary/10 hover:text-primary">
                          <Download className="w-5 h-5" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </ThreeDCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Suggestions;
