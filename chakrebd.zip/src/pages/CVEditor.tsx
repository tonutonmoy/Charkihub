import React, { useState, useRef } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Download, User, Briefcase, 
  GraduationCap, Plus, Trash2, Save, 
  Layout, Eye, Sparkles, Check, X,
  Mail, Phone, MapPin, Globe,
  Award, BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useReactToPrint } from 'react-to-print';
import { cn } from '@/lib/utils';

// --- Types ---
interface Education {
  id: string;
  degree: string;
  institution: string;
  year: string;
  result: string;
}

interface Experience {
  id: string;
  title: string;
  company: string;
  duration: string;
  description: string;
}

interface Reference {
  id: string;
  name: string;
  designation: string;
  organization: string;
  contact: string;
}

interface CVData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    address: string;
    permanentAddress: string;
    fatherName: string;
    motherName: string;
    dateOfBirth: string;
    nationality: string;
    religion: string;
    gender: string;
    maritalStatus: string;
    objective: string;
  };
  education: Education[];
  experience: Experience[];
  skills: string[];
  references: Reference[];
}

// --- Initial Data ---
const INITIAL_DATA: CVData = {
  personalInfo: {
    fullName: 'Md. Abdur Rahman',
    email: 'rahman.dev@example.com',
    phone: '+880 1700 000000',
    address: 'House 12, Road 5, Dhanmondi, Dhaka',
    permanentAddress: 'Vill: Puran Bazar, P.O: Chandpur, Dist: Chandpur',
    fatherName: 'Late Md. Fazlur Rahman',
    motherName: 'Mrs. Fatema Begum',
    dateOfBirth: '1995-05-20',
    nationality: 'Bangladeshi',
    religion: 'Islam',
    gender: 'Male',
    maritalStatus: 'Single',
    objective: 'To build a career in a challenging environment where I can utilize my skills and knowledge for the growth of the organization.'
  },
  education: [
    { id: '1', degree: 'B.Sc in Computer Science', institution: 'Dhaka University', year: '2018', result: '3.80/4.00' }
  ],
  experience: [
    { id: '1', title: 'Software Engineer', company: 'Tech Solutions Ltd.', duration: '2019 - Present', description: 'Working on full-stack web development using React and Node.js.' }
  ],
  skills: ['JavaScript', 'React', 'Node.js', 'SQL', 'Python'],
  references: [
    { id: '1', name: 'Dr. Kamal Uddin', designation: 'Professor', organization: 'Dhaka University', contact: 'kamal@du.ac.bd' }
  ]
};

// --- Templates ---

const GovtStandardTemplate = ({ data }: { data: CVData }) => (
  <div className="p-12 bg-white text-black font-serif min-h-[1100px] shadow-sm">
    <div className="text-center border-b-2 border-black pb-6 mb-8">
      <h1 className="text-3xl font-bold uppercase mb-2">{data.personalInfo.fullName}</h1>
      <p className="text-sm">{data.personalInfo.address}</p>
      <p className="text-sm">Email: {data.personalInfo.email} | Phone: {data.personalInfo.phone}</p>
    </div>

    <section className="mb-8">
      <h2 className="text-xl font-bold border-b border-black mb-4 uppercase">Career Objective</h2>
      <p className="text-sm leading-relaxed text-justify">{data.personalInfo.objective}</p>
    </section>

    <section className="mb-8">
      <h2 className="text-xl font-bold border-b border-black mb-4 uppercase">Personal Information</h2>
      <div className="grid grid-cols-2 gap-y-2 text-sm">
        <div className="font-bold">Mailing Address:</div><div>{data.personalInfo.address}</div>
        <div className="font-bold">Permanent Address:</div><div>{data.personalInfo.permanentAddress}</div>
        <div className="font-bold">Father's Name:</div><div>{data.personalInfo.fatherName}</div>
        <div className="font-bold">Mother's Name:</div><div>{data.personalInfo.motherName}</div>
        <div className="font-bold">Date of Birth:</div><div>{data.personalInfo.dateOfBirth}</div>
        <div className="font-bold">Nationality:</div><div>{data.personalInfo.nationality}</div>
        <div className="font-bold">Religion:</div><div>{data.personalInfo.religion}</div>
        <div className="font-bold">Gender:</div><div>{data.personalInfo.gender}</div>
        <div className="font-bold">Marital Status:</div><div>{data.personalInfo.maritalStatus}</div>
      </div>
    </section>

    <section className="mb-8">
      <h2 className="text-xl font-bold border-b border-black mb-4 uppercase">Educational Qualification</h2>
      <table className="w-full border-collapse border border-black text-sm">
        <thead>
          <tr className="bg-gray-100">
            <th className="border border-black p-2">Degree</th>
            <th className="border border-black p-2">Institution</th>
            <th className="border border-black p-2">Year</th>
            <th className="border border-black p-2">Result</th>
          </tr>
        </thead>
        <tbody>
          {data.education.map(edu => (
            <tr key={edu.id}>
              <td className="border border-black p-2">{edu.degree}</td>
              <td className="border border-black p-2">{edu.institution}</td>
              <td className="border border-black p-2 text-center">{edu.year}</td>
              <td className="border border-black p-2 text-center">{edu.result}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>

    <section className="mb-8">
      <h2 className="text-xl font-bold border-b border-black mb-4 uppercase">Experience</h2>
      <div className="space-y-4">
        {data.experience.map(exp => (
          <div key={exp.id}>
            <div className="flex justify-between font-bold text-sm">
              <span>{exp.title} - {exp.company}</span>
              <span>{exp.duration}</span>
            </div>
            <p className="text-sm mt-1">{exp.description}</p>
          </div>
        ))}
      </div>
    </section>

    <section className="mb-8">
      <h2 className="text-xl font-bold border-b border-black mb-4 uppercase">Skills</h2>
      <p className="text-sm">{data.skills.join(', ')}</p>
    </section>

    <section className="mb-8">
      <h2 className="text-xl font-bold border-b border-black mb-4 uppercase">References</h2>
      <div className="grid grid-cols-2 gap-8">
        {data.references.map(ref => (
          <div key={ref.id} className="text-sm">
            <p className="font-bold">{ref.name}</p>
            <p>{ref.designation}</p>
            <p>{ref.organization}</p>
            <p>Contact: {ref.contact}</p>
          </div>
        ))}
      </div>
    </section>
  </div>
);

const ModernResumeTemplate = ({ data }: { data: CVData }) => (
  <div className="p-12 bg-white text-slate-800 font-sans min-h-[1100px] shadow-sm flex gap-10">
    {/* Sidebar */}
    <div className="w-1/3 bg-slate-50 p-8 rounded-3xl">
      <div className="mb-10">
        <h1 className="text-2xl font-black text-primary leading-tight mb-2">{data.personalInfo.fullName}</h1>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Professional Resume</p>
      </div>

      <div className="space-y-6">
        <section>
          <h3 className="text-xs font-black uppercase tracking-widest text-primary mb-4">Contact</h3>
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2"><Mail className="w-4 h-4 text-primary" /> {data.personalInfo.email}</div>
            <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-primary" /> {data.personalInfo.phone}</div>
            <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" /> {data.personalInfo.address}</div>
          </div>
        </section>

        <section>
          <h3 className="text-xs font-black uppercase tracking-widest text-primary mb-4">Skills</h3>
          <div className="flex flex-wrap gap-2">
            {data.skills.map(skill => (
              <Badge key={skill} variant="secondary" className="bg-primary/10 text-primary border-none text-[10px] font-bold">
                {skill}
              </Badge>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-xs font-black uppercase tracking-widest text-primary mb-4">Education</h3>
          <div className="space-y-4">
            {data.education.map(edu => (
              <div key={edu.id}>
                <p className="font-bold text-sm">{edu.degree}</p>
                <p className="text-xs text-muted-foreground">{edu.institution}</p>
                <p className="text-xs font-bold mt-1">{edu.year} | {edu.result}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>

    {/* Main Content */}
    <div className="flex-1">
      <section className="mb-10">
        <h2 className="text-lg font-black mb-4 flex items-center gap-2">
          <User className="w-5 h-5 text-primary" /> Profile
        </h2>
        <p className="text-sm leading-relaxed text-muted-foreground">
          {data.personalInfo.objective}
        </p>
      </section>

      <section className="mb-10">
        <h2 className="text-lg font-black mb-6 flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-primary" /> Experience
        </h2>
        <div className="space-y-8">
          {data.experience.map(exp => (
            <div key={exp.id} className="relative pl-6 border-l-2 border-primary/20">
              <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-primary border-4 border-white" />
              <div className="flex justify-between mb-1">
                <h3 className="font-bold text-sm">{exp.title}</h3>
                <span className="text-xs font-bold text-primary">{exp.duration}</span>
              </div>
              <p className="text-xs font-bold text-muted-foreground mb-2">{exp.company}</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{exp.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-lg font-black mb-6 flex items-center gap-2">
          <Award className="w-5 h-5 text-primary" /> References
        </h2>
        <div className="grid grid-cols-1 gap-6">
          {data.references.map(ref => (
            <div key={ref.id} className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
              <p className="font-bold text-sm">{ref.name}</p>
              <p className="text-xs text-muted-foreground">{ref.designation} at {ref.organization}</p>
              <p className="text-xs font-bold text-primary mt-1">{ref.contact}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  </div>
);

// --- Main Component ---

const CVEditor = () => {
  const { templateId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [data, setData] = useState<CVData>(INITIAL_DATA);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>(searchParams.get('mode') === 'preview' ? 'preview' : 'edit');
  const [selectedTemplate, setSelectedTemplate] = useState(templateId === '2' ? 'resume' : 'cv');
  const [isSaved, setIsSaved] = useState(false);
  const componentRef = useRef<HTMLDivElement>(null);

  const handleSave = () => {
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
    // In a real app, we would save to a database here
    localStorage.setItem('cv_data', JSON.stringify(data));
  };

  const handlePrint = useReactToPrint({
    contentRef: componentRef,
    documentTitle: `${data.personalInfo.fullName}_CV`,
  });

  const updatePersonalInfo = (field: keyof CVData['personalInfo'], value: string) => {
    setData(prev => ({
      ...prev,
      personalInfo: { ...prev.personalInfo, [field]: value }
    }));
  };

  const addEducation = () => {
    setData(prev => ({
      ...prev,
      education: [...prev.education, { id: Date.now().toString(), degree: '', institution: '', year: '', result: '' }]
    }));
  };

  const removeEducation = (id: string) => {
    setData(prev => ({
      ...prev,
      education: prev.education.filter(e => e.id !== id)
    }));
  };

  const updateEducation = (id: string, field: keyof Education, value: string) => {
    setData(prev => ({
      ...prev,
      education: prev.education.map(e => e.id === id ? { ...e, [field]: value } : e)
    }));
  };

  const addExperience = () => {
    setData(prev => ({
      ...prev,
      experience: [...prev.experience, { id: Date.now().toString(), title: '', company: '', duration: '', description: '' }]
    }));
  };

  const removeExperience = (id: string) => {
    setData(prev => ({
      ...prev,
      experience: prev.experience.filter(e => e.id !== id)
    }));
  };

  const updateExperience = (id: string, field: keyof Experience, value: string) => {
    setData(prev => ({
      ...prev,
      experience: prev.experience.map(e => e.id === id ? { ...e, [field]: value } : e)
    }));
  };

  const addSkill = (skill: string) => {
    if (skill && !data.skills.includes(skill)) {
      setData(prev => ({
        ...prev,
        skills: [...prev.skills, skill]
      }));
    }
  };

  const removeSkill = (skill: string) => {
    setData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skill)
    }));
  };

  const addReference = () => {
    setData(prev => ({
      ...prev,
      references: [...prev.references, { id: Date.now().toString(), name: '', designation: '', organization: '', contact: '' }]
    }));
  };

  const updateReference = (id: string, field: keyof Reference, value: string) => {
    setData(prev => ({
      ...prev,
      references: prev.references.map(ref => ref.id === id ? { ...ref, [field]: value } : ref)
    }));
  };

  const removeReference = (id: string) => {
    setData(prev => ({
      ...prev,
      references: prev.references.filter(ref => ref.id !== id)
    }));
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full hover:bg-white"
              onClick={() => navigate('/cv')}
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div>
              <h1 className="text-3xl font-black tracking-tight">CV Editor</h1>
              <p className="text-muted-foreground font-medium">Customize your professional CV.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button 
              variant="outline" 
              className={cn(
                "rounded-xl h-12 px-6 font-bold bg-white border-border/50 shadow-sm transition-all",
                isSaved && "bg-green-50 text-green-600 border-green-200"
              )}
              onClick={handleSave}
            >
              {isSaved ? (
                <><Check className="mr-2 w-5 h-5" /> Saved!</>
              ) : (
                <><Save className="mr-2 w-5 h-5" /> Save Progress</>
              )}
            </Button>
            <Button onClick={handlePrint} className="rounded-xl h-12 px-8 font-black shadow-xl shadow-primary/20">
              <Download className="mr-2 w-5 h-5" /> Download PDF
            </Button>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          
          {/* Editor Panel */}
          <div className={cn(
            "flex-1 space-y-8 transition-all duration-500",
            activeTab === 'preview' ? 'hidden lg:block lg:opacity-50' : 'block'
          )}>
            <div className="flex items-center justify-between mb-8">
              <Button variant="ghost" className="rounded-xl font-bold" onClick={() => navigate('/cv')}>
                <ArrowLeft className="mr-2 w-5 h-5" /> Back to Templates
              </Button>
              <div className="flex gap-2">
                <Button 
                  variant={selectedTemplate === 'cv' ? 'default' : 'outline'} 
                  className="rounded-xl font-bold"
                  onClick={() => setSelectedTemplate('cv')}
                >
                  Govt CV
                </Button>
                <Button 
                  variant={selectedTemplate === 'resume' ? 'default' : 'outline'} 
                  className="rounded-xl font-bold"
                  onClick={() => setSelectedTemplate('resume')}
                >
                  Modern Resume
                </Button>
              </div>
            </div>

            <Card className="rounded-[2.5rem] border-border/50 shadow-xl overflow-hidden bg-card">
              <CardHeader className="bg-primary/5 p-8 border-b border-border/50">
                <CardTitle className="text-2xl font-black flex items-center gap-3">
                  <User className="w-6 h-6 text-primary" /> Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Full Name</label>
                    <Input value={data.personalInfo.fullName} onChange={e => updatePersonalInfo('fullName', e.target.value)} className="rounded-xl h-12" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Email Address</label>
                    <Input value={data.personalInfo.email} onChange={e => updatePersonalInfo('email', e.target.value)} className="rounded-xl h-12" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Phone Number</label>
                    <Input value={data.personalInfo.phone} onChange={e => updatePersonalInfo('phone', e.target.value)} className="rounded-xl h-12" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Mailing Address</label>
                    <Input value={data.personalInfo.address} onChange={e => updatePersonalInfo('address', e.target.value)} className="rounded-xl h-12" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Permanent Address</label>
                    <Input value={data.personalInfo.permanentAddress} onChange={e => updatePersonalInfo('permanentAddress', e.target.value)} className="rounded-xl h-12" />
                  </div>
                </div>
                
                {selectedTemplate === 'cv' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-border/50">
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Father's Name</label>
                      <Input value={data.personalInfo.fatherName} onChange={e => updatePersonalInfo('fatherName', e.target.value)} className="rounded-xl h-12" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Mother's Name</label>
                      <Input value={data.personalInfo.motherName} onChange={e => updatePersonalInfo('motherName', e.target.value)} className="rounded-xl h-12" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Date of Birth</label>
                      <Input type="date" value={data.personalInfo.dateOfBirth} onChange={e => updatePersonalInfo('dateOfBirth', e.target.value)} className="rounded-xl h-12" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Nationality</label>
                      <Input value={data.personalInfo.nationality} onChange={e => updatePersonalInfo('nationality', e.target.value)} className="rounded-xl h-12" />
                    </div>
                  </div>
                )}

                <div className="space-y-2 pt-6 border-t border-border/50">
                  <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Career Objective</label>
                  <textarea 
                    value={data.personalInfo.objective} 
                    onChange={e => updatePersonalInfo('objective', e.target.value)}
                    className="w-full min-h-[120px] rounded-xl bg-background border border-input p-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Education Section */}
            <Card className="rounded-[2.5rem] border-border/50 shadow-xl overflow-hidden bg-card">
              <CardHeader className="bg-primary/5 p-8 border-b border-border/50 flex flex-row items-center justify-between">
                <CardTitle className="text-2xl font-black flex items-center gap-3">
                  <GraduationCap className="w-6 h-6 text-primary" /> Education
                </CardTitle>
                <Button onClick={addEducation} size="sm" className="rounded-xl font-bold"><Plus className="w-4 h-4 mr-1" /> Add</Button>
              </CardHeader>
              <CardContent className="p-8 space-y-8">
                {data.education.map((edu, idx) => (
                  <div key={edu.id} className="relative space-y-4 p-6 rounded-3xl bg-muted/30 border border-border/50">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-4 right-4 text-destructive hover:bg-destructive/10"
                      onClick={() => removeEducation(edu.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Degree</label>
                        <Input value={edu.degree} onChange={e => updateEducation(edu.id, 'degree', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Institution</label>
                        <Input value={edu.institution} onChange={e => updateEducation(edu.id, 'institution', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Year</label>
                        <Input value={edu.year} onChange={e => updateEducation(edu.id, 'year', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Result</label>
                        <Input value={edu.result} onChange={e => updateEducation(edu.id, 'result', e.target.value)} className="rounded-xl h-10" />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Experience Section */}
            <Card className="rounded-[2.5rem] border-border/50 shadow-xl overflow-hidden bg-card">
              <CardHeader className="bg-primary/5 p-8 border-b border-border/50 flex flex-row items-center justify-between">
                <CardTitle className="text-2xl font-black flex items-center gap-3">
                  <Briefcase className="w-6 h-6 text-primary" /> Experience
                </CardTitle>
                <Button onClick={addExperience} size="sm" className="rounded-xl font-bold"><Plus className="w-4 h-4 mr-1" /> Add</Button>
              </CardHeader>
              <CardContent className="p-8 space-y-8">
                {data.experience.map((exp, idx) => (
                  <div key={exp.id} className="relative space-y-4 p-6 rounded-3xl bg-muted/30 border border-border/50">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-4 right-4 text-destructive hover:bg-destructive/10"
                      onClick={() => removeExperience(exp.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Job Title</label>
                        <Input value={exp.title} onChange={e => updateExperience(exp.id, 'title', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Company</label>
                        <Input value={exp.company} onChange={e => updateExperience(exp.id, 'company', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Duration</label>
                        <Input value={exp.duration} onChange={e => updateExperience(exp.id, 'duration', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2 md:col-span-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Description</label>
                        <textarea 
                          value={exp.description} 
                          onChange={e => updateExperience(exp.id, 'description', e.target.value)}
                          className="w-full min-h-[100px] rounded-xl bg-background border border-input p-4 text-sm focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Skills Section */}
            <Card className="rounded-[2.5rem] border-border/50 shadow-xl overflow-hidden bg-card">
              <CardHeader className="bg-primary/5 p-8 border-b border-border/50">
                <CardTitle className="text-2xl font-black flex items-center gap-3">
                  <Sparkles className="w-6 h-6 text-primary" /> Skills
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8 space-y-6">
                <div className="flex gap-2">
                  <Input 
                    placeholder="Add a skill (e.g. MS Word, Python)" 
                    className="rounded-xl h-12"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        addSkill((e.target as HTMLInputElement).value);
                        (e.target as HTMLInputElement).value = '';
                      }
                    }}
                  />
                  <Button className="rounded-xl h-12 px-6 font-bold">Add</Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {data.skills.map(skill => (
                    <Badge key={skill} className="bg-primary/10 text-primary border-none px-3 py-1.5 rounded-lg flex items-center gap-2 group">
                      {skill}
                      <button onClick={() => removeSkill(skill)} className="hover:text-destructive transition-colors">
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* References Section */}
            <Card className="rounded-[2.5rem] border-border/50 shadow-xl overflow-hidden bg-card">
              <CardHeader className="bg-primary/5 p-8 border-b border-border/50 flex flex-row items-center justify-between">
                <CardTitle className="text-2xl font-black flex items-center gap-3">
                  <BookOpen className="w-6 h-6 text-primary" /> References
                </CardTitle>
                <Button onClick={addReference} size="sm" className="rounded-xl font-bold"><Plus className="w-4 h-4 mr-1" /> Add</Button>
              </CardHeader>
              <CardContent className="p-8 space-y-8">
                {data.references.map((ref) => (
                  <div key={ref.id} className="relative space-y-4 p-6 rounded-3xl bg-muted/30 border border-border/50">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-4 right-4 text-destructive hover:bg-destructive/10"
                      onClick={() => removeReference(ref.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Name</label>
                        <Input value={ref.name} onChange={e => updateReference(ref.id, 'name', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Designation</label>
                        <Input value={ref.designation} onChange={e => updateReference(ref.id, 'designation', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Organization</label>
                        <Input value={ref.organization} onChange={e => updateReference(ref.id, 'organization', e.target.value)} className="rounded-xl h-10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black uppercase tracking-widest text-muted-foreground">Contact Info</label>
                        <Input value={ref.contact} onChange={e => updateReference(ref.id, 'contact', e.target.value)} className="rounded-xl h-10" />
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Preview Panel */}
          <div className={cn(
            "lg:w-[600px] xl:w-[800px] space-y-6 transition-all duration-500",
            activeTab === 'edit' ? 'hidden lg:block' : 'block'
          )}>
            <div className="sticky top-32 space-y-6">
              <div className="flex items-center justify-between bg-card p-4 rounded-2xl border border-border/50 shadow-lg">
                <div className="flex gap-2">
                  <Button 
                    variant={activeTab === 'edit' ? 'default' : 'ghost'} 
                    className="rounded-xl font-bold lg:hidden"
                    onClick={() => setActiveTab('edit')}
                  >
                    Editor
                  </Button>
                  <Button 
                    variant={activeTab === 'preview' ? 'default' : 'ghost'} 
                    className="rounded-xl font-bold lg:hidden"
                    onClick={() => setActiveTab('preview')}
                  >
                    Preview
                  </Button>
                </div>
              </div>

              <div className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-border/50 origin-top scale-[0.7] md:scale-100">
                <div ref={componentRef}>
                  {selectedTemplate === 'cv' ? (
                    <GovtStandardTemplate data={data} />
                  ) : (
                    <ModernResumeTemplate data={data} />
                  )}
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default CVEditor;
