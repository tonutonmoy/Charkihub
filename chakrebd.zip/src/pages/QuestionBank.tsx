import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Database, FileText, Download, Share2, ArrowRight, History } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ThreeDCard } from '../components/ThreeDCard';

import { Link } from 'react-router-dom';

const MOCK_QUESTIONS = [
  { id: '1', title: '45th BCS Preliminary Question', category: 'BCS', year: '2023', solved: true },
  { id: '2', title: 'Sonali Bank Senior Officer 2024', category: 'Bank', year: '2024', solved: true },
  { id: '3', title: 'Primary Teacher Recruitment 2024', category: 'Primary', year: '2024', solved: false },
  { id: '4', title: '44th BCS Written Question', category: 'BCS', year: '2022', solved: true },
  { id: '5', title: 'Combined Bank Officer 2025', category: 'Bank', year: '2025', solved: true },
  { id: '6', title: 'Railway Guard Exam 2023', category: 'Railway', year: '2023', solved: false },
];

const CATEGORIES = ['All', 'BCS', 'Bank', 'Primary', 'Railway'];

const QuestionBank = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredQuestions = MOCK_QUESTIONS.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold mb-4 uppercase tracking-widest border border-primary/20">
            <History className="w-4 h-4" />
            <span>Archive</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">প্রশ্ন ব্যাংক (Question Bank)</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Access a vast collection of previous years' exam questions with detailed solutions.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 bg-card p-6 rounded-[2rem] shadow-xl shadow-primary/5 border border-border/50">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              placeholder="Search previous questions..." 
              className="pl-12 h-14 rounded-xl border-border/50 focus-visible:ring-primary/30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {CATEGORIES.map(cat => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? 'default' : 'outline'}
                className="rounded-xl h-14 px-6 font-bold whitespace-nowrap"
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Questions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredQuestions.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <ThreeDCard>
                <Link to={`/qbank/${item.id}`}>
                  <Card className="h-full hover:shadow-2xl transition-all duration-500 border-border/50 group bg-card/80 backdrop-blur-sm rounded-[2rem] overflow-hidden">
                  <CardHeader className="pb-4">
                    <div className="flex justify-between items-start mb-6">
                      <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-500">
                        <Database className="w-7 h-7 text-primary" />
                      </div>
                      <Badge variant={item.solved ? 'default' : 'secondary'} className="rounded-lg px-3 py-1 font-black text-[10px] uppercase tracking-widest border-none">
                        {item.solved ? 'Solved' : 'Unsolved'}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl font-black group-hover:text-primary transition-colors leading-tight">
                      {item.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-bold text-muted-foreground">Year: {item.year}</p>
                      <Badge variant="outline" className="font-bold border-primary/20 text-primary">
                        {item.category}
                      </Badge>
                    </div>
                    <div className="pt-4 flex items-center justify-between border-t border-border/50">
                      <span className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-1">
                        View Solution <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </span>
                      <div className="flex gap-2">
                        <Button size="icon" variant="ghost" className="rounded-full w-10 h-10">
                          <Share2 className="w-5 h-5" />
                        </Button>
                        <Button size="icon" variant="ghost" className="rounded-full w-10 h-10 hover:bg-primary/10 hover:text-primary">
                          <Download className="w-5 h-5" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </ThreeDCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuestionBank;
