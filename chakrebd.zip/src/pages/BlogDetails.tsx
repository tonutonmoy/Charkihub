import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Share2, Calendar, User, Clock, 
  Facebook, Twitter, Linkedin, Link as LinkIcon, 
  Check, Bookmark, MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

const MOCK_BLOGS = [
  { 
    id: '1', 
    title: 'How to Crack 46th BCS Preliminary', 
    category: 'Exam Strategy', 
    author: 'Rahat Ahmed', 
    date: '10 April 2026', 
    readTime: '8 min read', 
    image: 'https://picsum.photos/seed/bcs/1200/600',
    content: `
      The BCS Preliminary exam is the first hurdle in the journey to becoming a cadre officer. 
      With the 46th BCS circular out, candidates are looking for the best strategies to ace the exam.
      
      Key areas to focus on:
      1. Bangladesh Affairs: Focus on the liberation war and recent developments.
      2. English Literature: Memorize the major works of famous authors.
      3. Mathematical Reasoning: Practice shortcuts for time management.
      
      Consistency is the key. Make a study routine and stick to it.
    `
  },
  // ...
];

const BlogDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const item = MOCK_BLOGS.find(b => b.id === id) || MOCK_BLOGS[0];
  const [showCopyPopup, setShowCopyPopup] = useState(false);

  const handleShare = (platform: string) => {
    const url = window.location.href;
    if (platform === 'copy') {
      navigator.clipboard.writeText(url);
      setShowCopyPopup(true);
      setTimeout(() => setShowCopyPopup(false), 2000);
    } else {
      const text = `Read this article: ${item.title}`;
      if (platform === 'facebook') window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
      if (platform === 'twitter') window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
      if (platform === 'linkedin') window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
    }
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30 relative">
      <AnimatePresence>
        {showCopyPopup && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className="fixed bottom-10 left-1/2 z-[100] bg-primary text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-bold"
          >
            <Check className="w-5 h-5" />
            Link copied to clipboard!
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 max-w-4xl">
        <Button 
          variant="ghost" 
          className="mb-8 font-bold hover:bg-primary/10 hover:text-primary transition-all rounded-xl"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="mr-2 w-5 h-5" /> Back to Blog
        </Button>

        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="rounded-[2.5rem] overflow-hidden border-border/50 shadow-2xl shadow-primary/5 bg-card">
            <div className="aspect-video relative overflow-hidden">
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <CardContent className="p-8 md:p-12">
              <div className="flex items-center gap-4 mb-8">
                <Badge className="bg-primary/10 text-primary border-none rounded-lg px-4 py-1 font-black uppercase tracking-widest">
                  {item.category}
                </Badge>
                <div className="flex items-center gap-2 text-sm text-muted-foreground font-bold">
                  <Clock className="w-4 h-4" />
                  {item.readTime}
                </div>
              </div>

              <h1 className="text-3xl md:text-5xl font-black mb-8 tracking-tight leading-tight">
                {item.title}
              </h1>

              <div className="flex items-center justify-between py-6 border-y border-border/50 mb-10">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary/20">
                    <img src={`https://i.pravatar.cc/100?u=${item.author}`} alt={item.author} />
                  </div>
                  <div>
                    <p className="font-black">{item.author}</p>
                    <p className="text-sm text-muted-foreground font-bold">{item.date}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="icon" variant="outline" className="rounded-full"><Bookmark className="w-4 h-4" /></Button>
                  <Button size="icon" variant="outline" className="rounded-full" onClick={() => handleShare('copy')}><LinkIcon className="w-4 h-4" /></Button>
                </div>
              </div>

              <div className="prose prose-lg max-w-none text-muted-foreground leading-relaxed">
                {item.content.split('\n').map((para, i) => (
                  <p key={i} className="mb-6">{para}</p>
                ))}
              </div>

              <div className="mt-16 pt-10 border-t border-border/50">
                <h3 className="text-xl font-black mb-8 tracking-tight">Share this Article</h3>
                <div className="flex flex-wrap gap-4">
                  <Button variant="outline" className="rounded-2xl h-14 px-8 font-bold hover:bg-blue-50 hover:text-blue-600" onClick={() => handleShare('facebook')}>
                    <Facebook className="mr-2 w-5 h-5" /> Facebook
                  </Button>
                  <Button variant="outline" className="rounded-2xl h-14 px-8 font-bold hover:bg-sky-50 hover:text-sky-500" onClick={() => handleShare('twitter')}>
                    <Twitter className="mr-2 w-5 h-5" /> Twitter
                  </Button>
                  <Button variant="outline" className="rounded-2xl h-14 px-8 font-bold hover:bg-blue-50 hover:text-blue-700" onClick={() => handleShare('linkedin')}>
                    <Linkedin className="mr-2 w-5 h-5" /> LinkedIn
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.article>
      </div>
    </div>
  );
};

export default BlogDetails;
