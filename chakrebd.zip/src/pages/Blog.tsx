import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Calendar, User, Clock, ArrowRight, Share2, Download, Bookmark } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ThreeDCard } from '../components/ThreeDCard';

import { Link } from 'react-router-dom';

const MOCK_BLOGS = [
  { id: '1', title: 'How to Crack 46th BCS Preliminary', category: 'Exam Strategy', author: 'Rahat Ahmed', date: '10 April 2026', readTime: '8 min read', image: 'https://picsum.photos/seed/bcs/800/500' },
  { id: '2', title: 'Top 10 Bank Job Interview Tips', category: 'Career Tips', author: 'Sumaiya Akter', date: '08 April 2026', readTime: '5 min read', image: 'https://picsum.photos/seed/bank/800/500' },
  { id: '3', title: 'Staying Motivated During Long Prep', category: 'Motivation', author: 'Dr. Karim', date: '05 April 2026', readTime: '6 min read', image: 'https://picsum.photos/seed/motivation/800/500' },
  { id: '4', title: 'English Grammar Shortcuts for Govt Jobs', category: 'Education', author: 'Prof. Selina', date: '02 April 2026', readTime: '10 min read', image: 'https://picsum.photos/seed/edu/800/500' },
  { id: '5', title: 'Railway Exam Pattern Analysis 2026', category: 'Exam Strategy', author: 'Expert Panel', date: '01 April 2026', readTime: '7 min read', image: 'https://picsum.photos/seed/rail/800/500' },
  { id: '6', title: 'Life as a BCS Cadre: What to Expect', category: 'Lifestyle', author: 'Anisul Islam', date: '28 March 2026', readTime: '12 min read', image: 'https://picsum.photos/seed/life/800/500' },
];

const CATEGORIES = ['All', 'Exam Strategy', 'Career Tips', 'Motivation', 'Education', 'Lifestyle'];

const BlogPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredBlogs = MOCK_BLOGS.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">ব্লগ (Blog)</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Insights, strategies, and success stories from experts and successful candidates.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 bg-card p-6 rounded-[2rem] shadow-xl shadow-primary/5 border border-border/50">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              placeholder="Search blog posts..." 
              className="pl-12 h-14 rounded-xl border-border/50 focus-visible:ring-primary/30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {CATEGORIES.map(cat => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? 'default' : 'outline'}
                className="rounded-xl h-14 px-6 font-bold whitespace-nowrap"
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Blog Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredBlogs.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <ThreeDCard>
                <Link to={`/blog/${item.id}`}>
                  <Card className="h-full hover:shadow-2xl transition-all duration-500 border-border/50 group bg-card/80 backdrop-blur-sm rounded-[2rem] overflow-hidden">
                  <div className="aspect-[16/10] overflow-hidden">
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <CardHeader className="pb-4">
                    <div className="flex items-center gap-2 mb-4">
                      <Badge variant="secondary" className="rounded-lg px-3 py-1 font-black text-[10px] uppercase tracking-widest bg-primary/10 text-primary border-none">
                        {item.category}
                      </Badge>
                      <span className="text-xs text-muted-foreground font-bold">{item.readTime}</span>
                    </div>
                    <CardTitle className="text-xl font-black group-hover:text-primary transition-colors leading-tight">
                      {item.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-muted overflow-hidden border border-border">
                        <img src={`https://i.pravatar.cc/100?u=${item.author}`} alt={item.author} />
                      </div>
                      <div className="text-xs">
                        <p className="font-bold">{item.author}</p>
                        <p className="text-muted-foreground">{item.date}</p>
                      </div>
                    </div>
                    <div className="pt-4 flex items-center justify-between border-t border-border/50">
                      <span className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-1">
                        Read Article <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </span>
                      <div className="flex gap-2">
                        <Button size="icon" variant="ghost" className="rounded-full w-8 h-8">
                          <Bookmark className="w-4 h-4" />
                        </Button>
                        <Button size="icon" variant="ghost" className="rounded-full w-8 h-8">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </ThreeDCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPage;
