import React from 'react';
import { motion } from 'motion/react';
import { UserPlus, Mail, Lock, User, ArrowRight, Github, Chrome } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../components/AuthContext';

const Signup = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    login();
    navigate('/admin');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 pt-20 pb-10 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="rounded-[2.5rem] border-border/50 shadow-2xl shadow-primary/5 bg-card overflow-hidden">
          <CardHeader className="pt-12 pb-8 text-center">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-primary/20">
              <UserPlus className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-3xl font-black tracking-tight">Create Account</CardTitle>
            <p className="text-muted-foreground mt-2 font-medium">Join 50,000+ job seekers today</p>
          </CardHeader>
          <CardContent className="space-y-6 px-8 md:px-12">
            <form onSubmit={handleSignup} className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input placeholder="John Doe" className="h-14 pl-12 rounded-xl border-border/50 bg-muted/30 focus-visible:ring-primary/30" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input placeholder="name@example.com" className="h-14 pl-12 rounded-xl border-border/50 bg-muted/30 focus-visible:ring-primary/30" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input type="password" placeholder="••••••••" className="h-14 pl-12 rounded-xl border-border/50 bg-muted/30 focus-visible:ring-primary/30" required />
                  </div>
                </div>
              </div>
              <Button type="submit" className="w-full h-14 rounded-xl font-black text-lg shadow-xl shadow-primary/20 group">
                Get Started
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </form>

            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-4 text-muted-foreground font-bold">Or sign up with</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="h-14 rounded-xl font-bold border-border/50 hover:bg-muted/50">
                <Chrome className="mr-2 w-5 h-5" /> Google
              </Button>
              <Button variant="outline" className="h-14 rounded-xl font-bold border-border/50 hover:bg-muted/50">
                <Github className="mr-2 w-5 h-5" /> Github
              </Button>
            </div>
          </CardContent>
          <CardFooter className="pb-12 pt-6 text-center justify-center">
            <p className="text-sm text-muted-foreground font-medium">
              Already have an account?{' '}
              <Link to="/login" className="text-primary font-black hover:underline">Login</Link>
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default Signup;
