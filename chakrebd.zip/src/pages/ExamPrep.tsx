import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, GraduationCap, BookOpen, Clock, ArrowRight, PlayCircle, Download } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ThreeDCard } from '../components/ThreeDCard';

import { Link } from 'react-router-dom';

const MOCK_PREP = [
  { id: '1', title: 'BCS Preliminary Masterclass', category: 'BCS', lessons: 120, duration: '45 Hours', rating: 4.9, price: 'Free' },
  { id: '2', title: 'Bank Job Math Shortcuts', category: 'Bank', lessons: 45, duration: '15 Hours', rating: 4.8, price: 'Premium' },
  { id: '3', title: 'Primary Teacher Exam Guide', category: 'Primary', lessons: 60, duration: '20 Hours', rating: 4.7, price: 'Free' },
  { id: '4', title: 'Railway Recruitment Prep', category: 'Railway', lessons: 30, duration: '10 Hours', rating: 4.6, price: 'Free' },
  { id: '5', title: 'English Grammar for Govt Jobs', category: 'General', lessons: 80, duration: '30 Hours', rating: 4.9, price: 'Premium' },
  { id: '6', title: 'Current Affairs 2026', category: 'General', lessons: 12, duration: '6 Hours', rating: 4.5, price: 'Free' },
];

const CATEGORIES = ['All', 'BCS', 'Bank', 'Primary', 'Railway', 'General'];

const ExamPrep = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredPrep = MOCK_PREP.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">পরীক্ষা প্রস্তুতি (Exam Prep)</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Structured courses and study materials to help you ace your government job exams.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 bg-card p-6 rounded-[2rem] shadow-xl shadow-primary/5 border border-border/50">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              placeholder="Search courses..." 
              className="pl-12 h-14 rounded-xl border-border/50 focus-visible:ring-primary/30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {CATEGORIES.map(cat => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? 'default' : 'outline'}
                className="rounded-xl h-14 px-6 font-bold whitespace-nowrap"
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Prep Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPrep.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <ThreeDCard>
                <Link to={`/prep/${item.id}`}>
                  <Card className="h-full hover:shadow-2xl transition-all duration-500 border-border/50 group bg-card/80 backdrop-blur-sm rounded-[2rem] overflow-hidden">
                  <div className="aspect-video relative overflow-hidden">
                    <img 
                      src={`https://picsum.photos/seed/prep${item.id}/800/450`} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <PlayCircle className="w-16 h-16 text-white" />
                    </div>
                    <Badge className="absolute top-4 right-4 bg-primary text-white font-black uppercase tracking-widest border-none">
                      {item.price}
                    </Badge>
                  </div>
                  <CardHeader className="pb-4">
                    <Badge variant="secondary" className="w-fit rounded-lg px-3 py-1 font-black text-[10px] uppercase tracking-widest mb-2">
                      {item.category}
                    </Badge>
                    <CardTitle className="text-xl font-black group-hover:text-primary transition-colors leading-tight">
                      {item.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-between text-sm font-bold text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-primary" />
                        {item.lessons} Lessons
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-secondary" />
                        {item.duration}
                      </div>
                    </div>
                    <div className="pt-4 flex items-center justify-between border-t border-border/50">
                      <span className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-1">
                        Start Learning <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </span>
                      <Button size="icon" variant="ghost" className="rounded-full w-10 h-10 hover:bg-primary/10 hover:text-primary">
                        <Download className="w-5 h-5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </ThreeDCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ExamPrep;
