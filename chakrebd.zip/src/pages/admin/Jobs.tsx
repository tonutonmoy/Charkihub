import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Plus, Search, Filter, MoreVertical, 
  Edit2, Trash2, Eye, Download, 
  ChevronLeft, ChevronRight, Briefcase,
  CheckCircle2, Clock, AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const MOCK_JOBS = [
  { id: '1', title: '46th BCS Preliminary Circular', org: 'BPSC', deadline: '2026-04-30', status: 'published', category: 'BCS' },
  { id: '2', title: 'Senior Officer (IT)', org: 'Sonali Bank', deadline: '2026-05-15', status: 'published', category: 'Bank' },
  { id: '3', title: 'Assistant Teacher', org: 'DPE', deadline: '2026-05-22', status: 'draft', category: 'Primary' },
  { id: '4', title: 'Station Master', org: 'Bangladesh Railway', deadline: '2026-05-10', status: 'published', category: 'Railway' },
  { id: '5', title: 'Sub-Inspector', org: 'Bangladesh Police', deadline: '2026-06-05', status: 'expired', category: 'Police' },
  { id: '6', title: 'Office Assistant', org: 'Ministry of Education', deadline: '2026-05-20', status: 'published', category: 'Ministry' },
];

const AdminJobs = () => {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Job Management</h1>
          <p className="text-muted-foreground mt-1">Manage all government job circulars and posts.</p>
        </div>
        <Button className="rounded-xl h-12 px-6 font-bold shadow-lg shadow-primary/20 gap-2">
          <Plus className="w-5 h-5" />
          Add New Job
        </Button>
      </div>

      {/* Filters & Search */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search jobs, organizations..." 
            className="pl-10 h-12 rounded-xl bg-card border-border/50 focus-visible:ring-primary/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="rounded-xl h-12 px-4 font-bold border-border/50 gap-2">
            <Filter className="w-4 h-4" />
            Filter
          </Button>
          <Button variant="outline" className="rounded-xl h-12 px-4 font-bold border-border/50">
            Export CSV
          </Button>
        </div>
      </div>

      {/* Jobs Table */}
      <Card className="rounded-2xl border-border/50 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-muted/50 border-b border-border">
                <th className="px-6 py-4 text-xs font-black uppercase tracking-widest text-muted-foreground">Job Title</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-widest text-muted-foreground">Organization</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-widest text-muted-foreground">Category</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-widest text-muted-foreground">Deadline</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-widest text-muted-foreground">Status</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-widest text-muted-foreground text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {MOCK_JOBS.map((job) => (
                <tr key={job.id} className="hover:bg-muted/30 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Briefcase className="w-4 h-4 text-primary" />
                      </div>
                      <span className="font-bold text-sm truncate max-w-[200px]">{job.title}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-muted-foreground">{job.org}</td>
                  <td className="px-6 py-4">
                    <Badge variant="secondary" className="rounded-lg font-bold text-[10px] uppercase tracking-wider">
                      {job.category}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 text-sm font-medium text-muted-foreground">{job.deadline}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {job.status === 'published' && (
                        <div className="flex items-center gap-1.5 text-green-500 font-bold text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Published
                        </div>
                      )}
                      {job.status === 'draft' && (
                        <div className="flex items-center gap-1.5 text-orange-500 font-bold text-xs">
                          <Clock className="w-3.5 h-3.5" />
                          Draft
                        </div>
                      )}
                      {job.status === 'expired' && (
                        <div className="flex items-center gap-1.5 text-destructive font-bold text-xs">
                          <AlertCircle className="w-3.5 h-3.5" />
                          Expired
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger className={cn(
                        "group/button inline-flex shrink-0 items-center justify-center rounded-lg border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
                        "hover:bg-muted hover:text-foreground aria-expanded:bg-muted aria-expanded:text-foreground dark:hover:bg-muted/50",
                        "size-8 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      )}>
                        <MoreVertical className="w-4 h-4" />
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl w-40">
                        <DropdownMenuItem className="gap-2">
                          <Eye className="w-4 h-4" /> View
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2">
                          <Edit2 className="w-4 h-4" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2">
                          <Download className="w-4 h-4" /> Download
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2 text-destructive">
                          <Trash2 className="w-4 h-4" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 bg-muted/20 border-t border-border flex items-center justify-between">
          <p className="text-xs text-muted-foreground font-medium">Showing 1 to 6 of 124 results</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" className="w-8 h-8 rounded-lg border-border/50" disabled>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" className="h-8 rounded-lg border-border/50 font-bold text-xs bg-primary text-white border-primary">1</Button>
            <Button variant="outline" size="sm" className="h-8 rounded-lg border-border/50 font-bold text-xs">2</Button>
            <Button variant="outline" size="sm" className="h-8 rounded-lg border-border/50 font-bold text-xs">3</Button>
            <Button variant="outline" size="icon" className="w-8 h-8 rounded-lg border-border/50">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default AdminJobs;
