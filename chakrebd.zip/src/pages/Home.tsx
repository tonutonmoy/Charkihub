import React from 'react';
import Hero from '../components/Hero';
import FeaturedGrid from '../components/FeaturedGrid';
import PreparationSection from '../components/PreparationSection';
import SmartSuggestions from '../components/SmartSuggestions';
import { Blog, Stats, Testimonials, Newsletter } from '../components/Sections';

const Home = () => {
  return (
    <>
      <Hero />
      <FeaturedGrid />
      <PreparationSection />
      <SmartSuggestions />
      <Stats />
      <Blog />
      <Testimonials />
      <Newsletter />
    </>
  );
};

export default Home;
