import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Filter, MapPin, Calendar, Briefcase, ArrowRight, Share2, Download } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { ThreeDCard } from '../components/ThreeDCard';

const MOCK_JOBS = [
  { id: '1', title: '46th BCS Circular', organization: 'Bangladesh Public Service Commission', location: 'Dhaka', deadline: '30 Apr 2026', category: 'BCS', type: 'Govt' },
  { id: '2', title: 'Senior Officer', organization: 'Sonali Bank PLC', location: 'Dhaka', deadline: '15 May 2026', category: 'Bank', type: 'Govt' },
  { id: '3', title: 'Assistant Teacher', organization: 'Directorate of Primary Education', location: 'All over Bangladesh', deadline: '22 May 2026', category: 'Primary', type: 'Govt' },
  { id: '4', title: 'Station Master', organization: 'Bangladesh Railway', location: 'Various', deadline: '10 May 2026', category: 'Railway', type: 'Govt' },
  { id: '5', title: 'Sub-Inspector', organization: 'Bangladesh Police', location: 'Various', deadline: '05 June 2026', category: 'Police', type: 'Govt' },
  { id: '6', title: 'Office Assistant', organization: 'Ministry of Education', location: 'Dhaka', deadline: '20 May 2026', category: 'Ministry', type: 'Govt' },
];

const CATEGORIES = ['All', 'BCS', 'Bank', 'Primary', 'Railway', 'Police', 'Ministry'];

const GovtJobs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredJobs = MOCK_JOBS.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         job.organization.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || job.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-black mb-4 tracking-tight">সরকারি চাকরি (Govt Jobs)</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Find the latest government job circulars in Bangladesh. Filter by category and search for your dream career.
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-12 bg-card p-6 rounded-[2rem] shadow-xl shadow-primary/5 border border-border/50">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input 
              placeholder="Search by job title or organization..." 
              className="pl-12 h-14 rounded-xl border-border/50 focus-visible:ring-primary/30"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
            {CATEGORIES.map(cat => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? 'default' : 'outline'}
                className="rounded-xl h-14 px-6 font-bold whitespace-nowrap"
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Jobs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredJobs.map((job, i) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <ThreeDCard>
                <Link to={`/jobs/${job.id}`}>
                  <Card className="h-full hover:shadow-2xl transition-all duration-500 border-border/50 group bg-card/80 backdrop-blur-sm rounded-[2rem] overflow-hidden">
                    <CardHeader className="pb-4">
                      <div className="flex justify-between items-start mb-4">
                        <Badge variant="secondary" className="rounded-lg px-3 py-1 font-black text-[10px] uppercase tracking-widest bg-primary/10 text-primary border-none">
                          {job.category}
                        </Badge>
                        <Badge variant="outline" className="rounded-lg px-3 py-1 font-bold text-[10px] uppercase tracking-widest border-secondary/20 text-secondary">
                          {job.type}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl font-black group-hover:text-primary transition-colors leading-tight">
                        {job.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-sm font-bold text-muted-foreground line-clamp-1">{job.organization}</p>
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                          <MapPin className="w-4 h-4 text-primary" />
                          {job.location}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                          <Calendar className="w-4 h-4 text-secondary" />
                          Deadline: {job.deadline}
                        </div>
                      </div>
                      <div className="pt-4 flex items-center justify-between">
                        <span className="text-xs font-black text-primary uppercase tracking-widest flex items-center gap-1">
                          View Details <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </span>
                        <div className="flex gap-2">
                          <Button size="icon" variant="ghost" className="rounded-full w-8 h-8">
                            <Share2 className="w-4 h-4" />
                          </Button>
                          <Button size="icon" variant="ghost" className="rounded-full w-8 h-8">
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </ThreeDCard>
            </motion.div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-20">
            <p className="text-xl text-muted-foreground font-bold">No jobs found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default GovtJobs;
