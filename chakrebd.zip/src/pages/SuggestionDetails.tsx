import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Share2, Download, Lightbulb, 
  FileText, User, Calendar, CheckCircle2, 
  Facebook, Twitter, Linkedin, Link as LinkIcon, Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

const MOCK_SUGGESTIONS = [
  { 
    id: '1', 
    title: 'BCS English Literature Suggestions', 
    category: 'BCS', 
    type: 'PDF', 
    date: '12 April 2026', 
    author: 'Dr. Rahim',
    description: 'Highly curated suggestions for the English Literature part of the BCS preliminary exam. Based on the analysis of the last 20 years of questions.',
    highlights: [
      'Top 50 most repeated authors',
      'Period-wise important works',
      'Nobel laureates and their masterpieces',
      'Commonly asked quotes and characters'
    ]
  },
  // ...
];

const SuggestionDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const item = MOCK_SUGGESTIONS.find(s => s.id === id) || MOCK_SUGGESTIONS[0];
  const [showCopyPopup, setShowCopyPopup] = useState(false);

  const handleShare = (platform: string) => {
    const url = window.location.href;
    if (platform === 'copy') {
      navigator.clipboard.writeText(url);
      setShowCopyPopup(true);
      setTimeout(() => setShowCopyPopup(false), 2000);
    } else {
      const text = `Check out this suggestion: ${item.title}`;
      if (platform === 'facebook') window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
      if (platform === 'twitter') window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
      if (platform === 'linkedin') window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
    }
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30 relative">
      <AnimatePresence>
        {showCopyPopup && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className="fixed bottom-10 left-1/2 z-[100] bg-primary text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-bold"
          >
            <Check className="w-5 h-5" />
            Link copied to clipboard!
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 max-w-4xl">
        <Button 
          variant="ghost" 
          className="mb-8 font-bold hover:bg-primary/10 hover:text-primary transition-all rounded-xl"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="mr-2 w-5 h-5" /> Back to Suggestions
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="rounded-[2.5rem] overflow-hidden border-border/50 shadow-2xl shadow-primary/5 bg-card">
            <div className="bg-gradient-to-br from-primary to-primary/80 p-8 md:p-12 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 p-12 opacity-10">
                <Lightbulb className="w-48 h-48" />
              </div>
              <div className="relative z-10">
                <div className="flex flex-wrap gap-3 mb-6">
                  <Badge className="bg-white/20 text-white border-none rounded-lg px-4 py-1 font-black uppercase tracking-widest">
                    {item.category}
                  </Badge>
                  <Badge className="bg-secondary text-white border-none rounded-lg px-4 py-1 font-black uppercase tracking-widest">
                    {item.type}
                  </Badge>
                </div>
                <h1 className="text-3xl md:text-5xl font-black mb-8 tracking-tight leading-tight">
                  {item.title}
                </h1>
                <div className="flex flex-wrap gap-6 text-sm font-bold">
                  <div className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    By {item.author}
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    {item.date}
                  </div>
                </div>
              </div>
            </div>

            <CardContent className="p-8 md:p-12">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div className="lg:col-span-2 space-y-10">
                  <section>
                    <h2 className="text-2xl font-black mb-4 tracking-tight">Description</h2>
                    <p className="text-muted-foreground leading-relaxed text-lg">
                      {item.description}
                    </p>
                  </section>

                  <section>
                    <h2 className="text-2xl font-black mb-4 tracking-tight">Key Highlights</h2>
                    <ul className="space-y-4">
                      {item.highlights.map((h, i) => (
                        <li key={i} className="flex items-start gap-3 text-muted-foreground">
                          <CheckCircle2 className="w-6 h-6 text-primary shrink-0 mt-0.5" />
                          <span className="text-lg font-bold">{h}</span>
                        </li>
                      ))}
                    </ul>
                  </section>
                </div>

                <div className="lg:col-span-1 space-y-8">
                  <div className="space-y-4">
                    <Button className="w-full h-16 rounded-2xl font-black text-lg shadow-xl shadow-primary/20">
                      Read Full Suggestion
                    </Button>
                    <Button variant="outline" className="w-full h-16 rounded-2xl font-black text-lg border-2">
                      <Download className="mr-2 w-6 h-6" /> Download PDF
                    </Button>
                  </div>

                  <div className="p-8 rounded-3xl border border-border/50 bg-card">
                    <h3 className="font-black mb-6 uppercase tracking-widest text-xs text-muted-foreground">Share Suggestion</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Button variant="outline" className="rounded-xl h-12" onClick={() => handleShare('facebook')}><Facebook className="w-5 h-5" /></Button>
                      <Button variant="outline" className="rounded-xl h-12" onClick={() => handleShare('twitter')}><Twitter className="w-5 h-5" /></Button>
                      <Button variant="outline" className="rounded-xl h-12" onClick={() => handleShare('linkedin')}><Linkedin className="w-5 h-5" /></Button>
                      <Button variant="outline" className="rounded-xl h-12" onClick={() => handleShare('copy')}><LinkIcon className="w-5 h-5" /></Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default SuggestionDetails;
