import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, CheckCircle2, Download, Layout, 
  Palette, Zap, Sparkles, ArrowRight, Eye, 
  Copy, Share2, Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ThreeDCard } from '../components/ThreeDCard';
import { Link } from 'react-router-dom';

const CV_TEMPLATES = [
  { 
    id: '1', 
    name: 'Standard Govt Format', 
    desc: 'The most widely accepted format for Bangladeshi government job applications.',
    image: 'https://picsum.photos/seed/cv1/600/800',
    category: 'Govt Standard',
    popular: true
  },
  { 
    id: '2', 
    name: 'Modern Corporate', 
    desc: 'Clean, minimalist design suitable for private banks and multinational companies.',
    image: 'https://picsum.photos/seed/cv2/600/800',
    category: 'Corporate',
    popular: false
  },
  { 
    id: '3', 
    name: 'Academic/Research', 
    desc: 'Detailed format focusing on publications, research, and academic achievements.',
    image: 'https://picsum.photos/seed/cv3/600/800',
    category: 'Academic',
    popular: false
  },
  { 
    id: '4', 
    name: 'Creative Professional', 
    desc: 'Visual-heavy layout for designers, marketers, and creative roles.',
    image: 'https://picsum.photos/seed/cv4/600/800',
    category: 'Creative',
    popular: false
  },
];

const CATEGORIES = ['All', 'Govt Standard', 'Corporate', 'Academic', 'Creative'];

const CVBuilder = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [showCopyPopup, setShowCopyPopup] = useState(false);

  const filteredTemplates = CV_TEMPLATES.filter(t => 
    selectedCategory === 'All' || t.category === selectedCategory
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(window.location.href);
    setShowCopyPopup(true);
    setTimeout(() => setShowCopyPopup(false), 2000);
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30 relative">
      {/* Copy Notification Popup */}
      <AnimatePresence>
        {showCopyPopup && (
          <motion.div
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className="fixed bottom-10 left-1/2 z-[100] bg-primary text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-bold"
          >
            <Check className="w-5 h-5" />
            Link copied to clipboard!
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold mb-6 uppercase tracking-widest border border-primary/20">
              <Sparkles className="w-4 h-4" />
              <span>Smart CV Builder</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-black mb-6 tracking-tight">
              Bangladesh's Best <span className="text-primary">CV Templates</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Choose from our curated collection of ATS-friendly templates designed specifically for the Bangladeshi job market.
            </p>
          </motion.div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {CATEGORIES.map(cat => (
            <Button
              key={cat}
              variant={selectedCategory === cat ? 'default' : 'outline'}
              className="rounded-xl h-12 px-6 font-bold transition-all"
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </Button>
          ))}
        </div>

        {/* Templates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {filteredTemplates.map((template, i) => (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <ThreeDCard>
                <Card className="h-full border-border/50 bg-card rounded-[2.5rem] overflow-hidden group hover:shadow-2xl transition-all duration-500">
                  <div className="aspect-[3/4] relative overflow-hidden bg-muted">
                    <img 
                      src={template.image} 
                      alt={template.name} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-6 gap-4">
                      <Link to={`/cv/edit/${template.id}`} className="w-full">
                        <Button className="w-full rounded-xl font-black h-12 shadow-lg shadow-primary/20">
                          Use This Template
                        </Button>
                      </Link>
                      <Link to={`/cv/edit/${template.id}?mode=preview`} className="w-full">
                        <Button variant="outline" className="w-full rounded-xl font-black h-12 bg-white/10 border-white/20 text-white hover:bg-white/20">
                          <Eye className="mr-2 w-5 h-5" /> Preview
                        </Button>
                      </Link>
                    </div>
                    {template.popular && (
                      <Badge className="absolute top-4 left-4 bg-secondary text-white font-black uppercase tracking-widest border-none">
                        Most Used
                      </Badge>
                    )}
                  </div>
                  <CardHeader className="p-6">
                    <Badge variant="secondary" className="w-fit rounded-lg px-3 py-1 font-black text-[10px] uppercase tracking-widest mb-2 bg-primary/10 text-primary border-none">
                      {template.category}
                    </Badge>
                    <CardTitle className="text-xl font-black group-hover:text-primary transition-colors">
                      {template.name}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground font-medium line-clamp-2 mt-2">
                      {template.desc}
                    </p>
                  </CardHeader>
                  <div className="px-6 pb-6 flex items-center justify-between border-t border-border/50 pt-4">
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" className="rounded-full w-9 h-9" onClick={handleCopy}>
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="rounded-full w-9 h-9">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" className="font-black text-primary uppercase tracking-widest text-[10px] group/btn">
                      Details <ArrowRight className="ml-1 w-3 h-3 group-hover/btn:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </Card>
              </ThreeDCard>
            </motion.div>
          ))}
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-24">
          {[
            { title: 'ATS Friendly', icon: Zap, desc: 'Optimized for automated screening systems.' },
            { title: 'PDF Export', icon: Download, desc: 'High-quality vector PDF for crisp printing.' },
            { title: 'Easy Edit', icon: Palette, desc: 'Simple interface to update your info anytime.' },
          ].map((feature, i) => (
            <div key={i} className="flex flex-col items-center text-center p-8 rounded-[2.5rem] bg-card border border-border/50 shadow-sm">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
                <feature.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-black mb-3 tracking-tight">{feature.title}</h3>
              <p className="text-muted-foreground font-medium">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Copy Success Popup */}
      <AnimatePresence>
        {showCopyPopup && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 bg-primary text-white px-8 py-4 rounded-2xl shadow-2xl font-black flex items-center gap-3"
          >
            <Check className="w-6 h-6" />
            Link Copied to Clipboard!
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CVBuilder;
