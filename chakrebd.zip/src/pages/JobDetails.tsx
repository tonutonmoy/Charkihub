import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ArrowLeft, Share2, Download, Calendar, MapPin, 
  Briefcase, Building2, CheckCircle2, Facebook, 
  Twitter, Linkedin, Link as LinkIcon 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

const MOCK_JOBS = [
  { 
    id: '1', 
    title: '46th BCS Circular', 
    organization: 'Bangladesh Public Service Commission', 
    location: 'Dhaka', 
    deadline: '30 Apr 2026', 
    category: 'BCS', 
    type: 'Govt',
    description: 'The 46th BCS circular has been published for various cadres. This is a great opportunity for graduates to join the civil service of Bangladesh.',
    requirements: [
      'Graduation or equivalent degree from a recognized university.',
      'Age between 21 to 30 years (Relaxable for quota candidates).',
      'Must be a citizen of Bangladesh.'
    ],
    salary: 'Grade 9 (Pay Scale 2015)',
    postedDate: '10 March 2026'
  },
  // ... other jobs would be here
];

const JobDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const job = MOCK_JOBS.find(j => j.id === id) || MOCK_JOBS[0];

  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = `Check out this job: ${job.title} at ${job.organization}`;
    
    if (platform === 'facebook') {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
    } else if (platform === 'twitter') {
      window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, '_blank');
    } else if (platform === 'linkedin') {
      window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`, '_blank');
    } else {
      navigator.clipboard.writeText(url);
      alert('Link copied to clipboard!');
    }
  };

  const handleDownload = () => {
    // In a real app, this would trigger a PDF generation or download
    alert('Downloading PDF Circular...');
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-muted/30">
      <div className="container mx-auto px-4 max-w-4xl">
        <Button 
          variant="ghost" 
          className="mb-8 font-bold hover:bg-primary/10 hover:text-primary transition-all rounded-xl"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="mr-2 w-5 h-5" /> Back to Jobs
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="rounded-[2.5rem] overflow-hidden border-border/50 shadow-2xl shadow-primary/5 bg-card">
            <div className="bg-primary p-8 md:p-12 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 p-12 opacity-10">
                <Building2 className="w-48 h-48" />
              </div>
              <div className="relative z-10">
                <div className="flex flex-wrap gap-3 mb-6">
                  <Badge className="bg-white/20 hover:bg-white/30 text-white border-none rounded-lg px-4 py-1 font-black uppercase tracking-widest">
                    {job.category}
                  </Badge>
                  <Badge className="bg-secondary text-white border-none rounded-lg px-4 py-1 font-black uppercase tracking-widest">
                    {job.type}
                  </Badge>
                </div>
                <h1 className="text-3xl md:text-5xl font-black mb-4 tracking-tight leading-tight">
                  {job.title}
                </h1>
                <p className="text-xl text-primary-foreground/90 font-bold mb-8 flex items-center gap-2">
                  <Building2 className="w-6 h-6" />
                  {job.organization}
                </p>
                <div className="flex flex-wrap gap-6 text-sm font-bold">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5" />
                    {job.location}
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    Deadline: {job.deadline}
                  </div>
                </div>
              </div>
            </div>

            <CardContent className="p-8 md:p-12">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {/* Main Content */}
                <div className="lg:col-span-2 space-y-10">
                  <section>
                    <h2 className="text-2xl font-black mb-4 tracking-tight">Job Description</h2>
                    <p className="text-muted-foreground leading-relaxed text-lg">
                      {job.description}
                    </p>
                  </section>

                  <section>
                    <h2 className="text-2xl font-black mb-4 tracking-tight">Requirements</h2>
                    <ul className="space-y-4">
                      {job.requirements.map((req, i) => (
                        <li key={i} className="flex items-start gap-3 text-muted-foreground">
                          <CheckCircle2 className="w-6 h-6 text-primary shrink-0 mt-0.5" />
                          <span className="text-lg">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </section>

                  <section className="p-8 rounded-3xl bg-muted/50 border border-border/50">
                    <h2 className="text-xl font-black mb-4 tracking-tight">Additional Info</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div>
                        <p className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-1">Salary Range</p>
                        <p className="font-bold text-lg">{job.salary}</p>
                      </div>
                      <div>
                        <p className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-1">Posted Date</p>
                        <p className="font-bold text-lg">{job.postedDate}</p>
                      </div>
                    </div>
                  </section>
                </div>

                {/* Sidebar Actions */}
                <div className="lg:col-span-1 space-y-8">
                  <div className="space-y-4">
                    <Button className="w-full h-16 rounded-2xl font-black text-lg shadow-xl shadow-primary/20">
                      Apply Now
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full h-16 rounded-2xl font-black text-lg border-2"
                      onClick={handleDownload}
                    >
                      <Download className="mr-2 w-6 h-6" /> Download PDF
                    </Button>
                  </div>

                  <div className="p-8 rounded-3xl border border-border/50 bg-card">
                    <h3 className="font-black mb-6 uppercase tracking-widest text-xs text-muted-foreground">Share this Job</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <Button 
                        variant="outline" 
                        className="rounded-xl h-12 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200"
                        onClick={() => handleShare('facebook')}
                      >
                        <Facebook className="w-5 h-5" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="rounded-xl h-12 hover:bg-sky-50 hover:text-sky-500 hover:border-sky-200"
                        onClick={() => handleShare('twitter')}
                      >
                        <Twitter className="w-5 h-5" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="rounded-xl h-12 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200"
                        onClick={() => handleShare('linkedin')}
                      >
                        <Linkedin className="w-5 h-5" />
                      </Button>
                      <Button 
                        variant="outline" 
                        className="rounded-xl h-12"
                        onClick={() => handleShare('copy')}
                      >
                        <LinkIcon className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default JobDetails;
