import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './components/LanguageContext';
import { ThemeProvider } from './components/ThemeContext';
import { AuthProvider } from './components/AuthContext';
import Navbar from './components/Navbar';
import { Footer } from './components/Sections';
import Home from './pages/Home';
import GovtJobs from './pages/GovtJobs';
import JobDetails from './pages/JobDetails';
import ExamPrep from './pages/ExamPrep';
import Suggestions from './pages/Suggestions';
import QuestionBank from './pages/QuestionBank';
import CVBuilder from './pages/CVBuilder';
import CVEditor from './pages/CVEditor';
import BlogPage from './pages/Blog';
import BlogDetails from './pages/BlogDetails';
import PrepDetails from './pages/PrepDetails';
import SuggestionDetails from './pages/SuggestionDetails';
import QuestionDetails from './pages/QuestionDetails';
import Login from './pages/Login';
import Signup from './pages/Signup';
import AdminLayout from './components/AdminLayout';
import AdminDashboard from './pages/admin/Dashboard';
import AdminJobs from './pages/admin/Jobs';
import AdminUsers from './pages/admin/Users';
import AdminCV from './pages/admin/CV';
import AdminPlaceholder from './pages/admin/Placeholder';

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <Router>
          <div className="min-h-screen bg-background text-foreground selection:bg-primary/20 selection:text-primary">
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<><Navbar /><main><Home /></main><Footer /></>} />
              <Route path="/jobs" element={<><Navbar /><main><GovtJobs /></main><Footer /></>} />
              <Route path="/jobs/:id" element={<><Navbar /><main><JobDetails /></main><Footer /></>} />
              <Route path="/prep" element={<><Navbar /><main><ExamPrep /></main><Footer /></>} />
              <Route path="/prep/:id" element={<><Navbar /><main><PrepDetails /></main><Footer /></>} />
              <Route path="/suggestions" element={<><Navbar /><main><Suggestions /></main><Footer /></>} />
              <Route path="/suggestions/:id" element={<><Navbar /><main><SuggestionDetails /></main><Footer /></>} />
              <Route path="/qbank" element={<><Navbar /><main><QuestionBank /></main><Footer /></>} />
              <Route path="/qbank/:id" element={<><Navbar /><main><QuestionDetails /></main><Footer /></>} />
              <Route path="/cv" element={<><Navbar /><main><CVBuilder /></main><Footer /></>} />
              <Route path="/cv/edit/:templateId" element={<><Navbar /><main><CVEditor /></main><Footer /></>} />
              <Route path="/blog" element={<><Navbar /><main><BlogPage /></main><Footer /></>} />
              <Route path="/blog/:id" element={<><Navbar /><main><BlogDetails /></main><Footer /></>} />
              <Route path="/login" element={<><Navbar /><main><Login /></main><Footer /></>} />
              <Route path="/signup" element={<><Navbar /><main><Signup /></main><Footer /></>} />

              {/* Admin Routes */}
              <Route path="/admin" element={<AdminLayout><AdminDashboard /></AdminLayout>} />
              <Route path="/admin/jobs" element={<AdminLayout><AdminJobs /></AdminLayout>} />
              <Route path="/admin/users" element={<AdminLayout><AdminUsers /></AdminLayout>} />
              <Route path="/admin/exam" element={<AdminLayout><AdminPlaceholder title="Exam Content" /></AdminLayout>} />
              <Route path="/admin/suggestions" element={<AdminLayout><AdminPlaceholder title="Suggestions" /></AdminLayout>} />
              <Route path="/admin/qbank" element={<AdminLayout><AdminPlaceholder title="Question Bank" /></AdminLayout>} />
              <Route path="/admin/cv" element={<AdminLayout><AdminCV /></AdminLayout>} />
              <Route path="/admin/blog" element={<AdminLayout><AdminPlaceholder title="Blog Management" /></AdminLayout>} />
              <Route path="/admin/notifications" element={<AdminLayout><AdminPlaceholder title="Notifications" /></AdminLayout>} />
              <Route path="/admin/settings" element={<AdminLayout><AdminPlaceholder title="Settings" /></AdminLayout>} />
            </Routes>
          </div>
        </Router>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
